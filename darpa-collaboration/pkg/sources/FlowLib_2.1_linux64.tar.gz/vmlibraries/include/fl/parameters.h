/*
 * Copyright (c) ICG. All rights reserved.
 *
 * Institute for Computer Graphics and Vision
 * Graz University of Technology / Austria
 *
 *
 * This software is distributed WITHOUT ANY WARRANTY; without even
 * the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the above copyright notices for more information.
 *
 *
 * Project     : FlowLib2
 * Module      : Parameters
 * Class       : fl::Parameters
 * Language    : C++
 * Description : Definition of paramter class (implemented as singleton)
 *
 * Author     : Manuel Werlberger
 * EMail      : werlberger@icg.tugraz.at
 *
 */

#ifndef FL_PARAMETERS_H
#define FL_PARAMETERS_H


#include <ostream>
#include <iu/iucore/coredefs.h>
#include "fldefs.h"

namespace fl {
/** Parameters structure holds parameters for flow calculations.
 */
class Parameters
{
public:
  // hidden ctor, dtor, copy ctor and assign op due to singleton
  Parameters() :
    verbose(0),
    model(HL1_PRIMAL_DUAL),
    lambda(50.0f), epsilon_u(0.001f), iters(100), warps(5),
    levels(fl::MAX_PYRAMIDAL_LEVELS), start_level(fl::MAX_PYRAMIDAL_LEVELS), stop_level(0),
    scale_factor(0.5f), interpolation_method(IU_INTERPOLATE_CUBIC),
    regularization_tensor_weight_sigma(1.0f),
    regularization_tensor_weight_alpha(5.0f), regularization_tensor_weight_q(0.5f),
    gamma_c(0.01f), epsilon_c(0.01f),
    alpha0(8.0f), alpha1(1.0f),
    nltv_alpha(4.0f), nltv_beta(3),
    //      use_adaptive_lambda(false),
    //      quad_fit_discretization(0.5f), quad_fit_dataterm(fl::QUAD_FIT_DATATERM_AD),
    str_tex_decomp_method(STR_TEX_DECOMP_OFF), str_tex_decomp_smoothing_amount(1.0f),
    str_tex_decomp_weight(0.8f), str_tex_decomp_rof_iterations(100),
    //      evaluate_energies(false),
    gpu_compute_capability_major(0), gpu_compute_capability_minor(0)
  {
  }

  ~Parameters() {};

  int verbose; /**< Verbosity flag. Adjusts the amount of debug/verbose output on the console. \n Default: 0*/
  Model model; /**< Current model settings for flow calculations. */
  float lambda; /**< Amount of weighting the regularization of u against the optical flow constraint. \n Default: 0.02 */
  float epsilon_u; /**< Parameter for Huber regularity (for u) that models the threshold for the quadratic penalization. \n Default: 0.05 */
  unsigned int iters; /**< Number of iterations per warping step. \n Default: 10 */
  unsigned int warps; /**< Number of warps. \n Default: 5 */
  unsigned int levels; /**< Number of maximal used levels. \n Default: MAX_PYRAMIDAL_LEVELS -- auotmatically determined due to scale factor.  \n This variable effects initialization of input data!*/
  unsigned int start_level; /**< Level where calculation start. Value between levels-1 and 0 is ok. \n Default: start_level is set to coarsest level. */
  unsigned int stop_level; /** Level where calculation stop. Value between levels-1 and 0 is ok. \n Default: stop_level is set to fines level (0). */
  float scale_factor; /**< Scale factor from one level to the next. \n Default: 0.5  \n This variable effects initialization of input data!*/
  IuInterpolationType interpolation_method; /**< Interpolation method that is used for resizing input images, warping and wherever it is supported. \n Default: linear */
  //float time; /**< The temporal position where the flow points to. 0.0 meaning the first image, 1.0 the second i. and 0.5 exactly in the middle of the two. */

  // regularization weighting
  float regularization_tensor_weight_sigma; /**< Sigma for gaussian prefilter of (fixed) input image before calculating the tensor matrix. \n Default: 1.0 */
  float regularization_tensor_weight_alpha; /**< Multiplicative weighting for edge norm for tensor calculations. \n Default: 10 */
  float regularization_tensor_weight_q; /**< Exponential weighting for edge norm for tensor calculations. \n Default: 0.5 */

  // illumination estimation
  float gamma_c; /**< Scales the value of c to be in approx the same range than the flow vectors (needed for primal-dual opt.). \n Default: 0.001 */
  float lambda_c; /**< Amount of weighting the regularization of c against the optical flow constraint. \n Default: 0.2 */
  float epsilon_c; /**< Parameter for Huber regularity (for c) that models the threshold for the quadratic penalization. \n Default: 0.5 */

  float alpha0; /**< */
  float alpha1; /**< */

  //  // occlusion/confidence refinement
  //  bool use_adaptive_lambda;

  //  // quad-fit optimization
  //  float quad_fit_discretization;
  //  fl::QuadFitDataTerm quad_fit_dataterm;

  // nonlocal models
  float nltv_alpha;
  int nltv_beta;

  // Input image preprocessing
  StructureTextureDecompositionMethod str_tex_decomp_method; /**< Method of structure-texture decomposition of input images. \n Default: OFF */
  float str_tex_decomp_smoothing_amount; /**< Sets the amount of smoothing for Gauss and ROF denoising for the str-tex decomposition. \n Default: 1.0f */
  float str_tex_decomp_weight; /**< Sets the amount of smoothing for Gauss and ROF denoising for the str-tex decomposition. \n Default: 1.0f */
  int str_tex_decomp_rof_iterations; /**< Sets the number of iterations when doing ROF denoising for str-tex decomposition. \n Default: 100 */

  //  // Energy calculations
  //  bool evaluate_energies;

  // GPU CONFIGURATION
  int gpu_compute_capability_major; /**< additional variable for major compute capability because npp is not aware of 2.0. */
  int gpu_compute_capability_minor; /**< additional variable for minor compute capability because npp is not aware of 2.0. */

  friend std::ostream& operator<<( std::ostream& stream, const Parameters& params );


  /** Internal parameters (nested class).
   * @warning Do not mess around with these. This will brake the calculations! (except block_size if you know what you are doing....)
   */
  class ParametersInternal
  {
  public:
    ParametersInternal() :
      smallest_level_size(8), init_u(true), init_v(true), init_c(true)
    {
    }

    static unsigned int block_size; /**< Standard block size. This is adapted when ghe gpu_compute_capability is updated. @note This is only a suggestion! */
    unsigned int smallest_level_size; /**< Denotes the minimum of the shorter side on the coarsest level. @note This one must be >= 16. */

    // flags for init variables
    bool init_u;
    bool init_v;
    bool init_c;

  private:
    ParametersInternal(ParametersInternal const&);  // intentionally not implemented
    ParametersInternal& operator=(ParametersInternal const&);  // intentionally not implemented
  };
  ParametersInternal intern_params;

private:
  Parameters(Parameters const&);  // intentionally not implemented
  Parameters& operator=(Parameters const&);  // intentionally not implemented
};

} // namespace fl

#endif // FL_PARAMETERS_H
