/*
 * Copyright (c) ICG. All rights reserved.
 *
 * Institute for Computer Graphics and Vision
 * Graz University of Technology / Austria
 *
 *
 * This software is distributed WITHOUT ANY WARRANTY; without even
 * the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the above copyright notices for more information.
 *
 *
 * Project     : FlowLib
 * Module      : testing
 * Language    : C++/CUDA
 * Description : Just a simple CUDA test
 *
 * Author     : Manuel Werlberger
 * EMail      : werlberger@icg.tugraz.at
 *
 */

// system includes
#include <iostream>
#include <stdio.h>
#include <limits>

#include <cv.h>
#include <highgui.h>
#include <cuda_runtime.h>
#include <iu/iucore.h>
#include <iu/iuio.h>
#include <iu/iumath.h>
#include <fl/flowlib.h>

int main( int argc, char** argv )
{
  cudaSetDevice(0); // set whatever device you wanna use...

  if(argc < 3)
  {
    std::cout << "usage: flowlib2_simpletest input_filename_1 input_filename_2" << std::endl;
    exit(EXIT_FAILURE);
  }

  // process parameters
  const std::string fname1 = argv[1];
  const std::string fname2 = argv[2];
  std::cout << "reading input images" << std::endl
            << "fixed image = " << fname1 << std::endl
            << "moving image = " << fname2 << std::endl;

  // Init FlowLib and set 2 images
  fl::FlowLib flow(0);
  bool ready = false;

#if 0
  // show how opencv wrapper would work

  // read two test images (must be of equal size!!)
  cv::Mat mat1 = cv::imread(fname1, 0);
  cv::Mat mat2 = cv::imread(fname2, 0);
  
  // convert to 32-bit float images
  IuSize sz(mat1.cols, mat1.rows);
  iu::ImageCpu_32f_C1 im1(sz);
  iu::ImageCpu_32f_C1 im2(sz);
  cv::Mat mat1_32f(sz.height, sz.width, CV_32FC1, im1.data(), im1.pitch());
  cv::Mat mat2_32f(sz.height, sz.width, CV_32FC1, im2.data(), im2.pitch());
  mat1.convertTo(mat1_32f, mat1_32f.type(), 1.0f/255.0f, 0);
  mat2.convertTo(mat2_32f, mat2_32f.type(), 1.0f/255.0f, 0);

  // Copy Cpu images to Gpu images
  iu::ImageGpu_32f_C1 cu_im1(sz);
  iu::ImageGpu_32f_C1 cu_im2(sz);
  iu::copy(&im1, &cu_im1);
  iu::copy(&im2, &cu_im2);

  ready = flow.setInputImages(&cu_im1, &cu_im2);
#else

  // read images using imageutilities
  iu::ImageGpu_32f_C1 *cu_im1 = iu::imread_cu32f_C1(fname1);
  iu::ImageGpu_32f_C1 *cu_im2 = iu::imread_cu32f_C1(fname2);

  ready = flow.setInputImages(cu_im1, cu_im2);
#endif

  
  // parametrization
  flow.parameters().model = fl::HL1_ILLUMINATION_PRIMAL_DUAL;
  flow.parameters().iters = 100;
  flow.parameters().warps = 10;
  flow.parameters().scale_factor = 0.8f;
  flow.parameters().lambda = 40.0f;
  flow.parameters().gamma_c = 0.01f;
  if(!ready)
    return EXIT_FAILURE;
  
  // do the calculations
  flow.calculate();

  // write flo result (see vision.middlebury.edu for more information of flo file format)
  flow.writeFloFile("simple_test_output.flo", 0);

  
  // results and display
#if 0
  // show how opencv wrapper would work
  IuSize result_sz;
  flow.getSize(flow.parameters().stop_level, result_sz);
  iu::ImageGpu_32f_C1 cu_u(result_sz);
  iu::ImageGpu_32f_C1 cu_v(result_sz);
  iu::ImageGpu_32f_C1 cu_illumination(result_sz);
  

  iu::ImageCpu_32f_C1 u(result_sz);
  iu::ImageCpu_32f_C1 v(result_sz);
  iu::ImageCpu_32f_C1 illumination(result_sz);
  cv::Mat mat_u(result_sz.height, result_sz.width, CV_32FC1, u.data(), u.pitch());
  cv::Mat mat_v(result_sz.height, result_sz.width, CV_32FC1, v.data(), v.pitch());
  cv::Mat mat_illumination(result_sz.height, result_sz.width, CV_32FC1, illumination.data(), illumination.pitch());

  flow.getU_32f_C1(flow.parameters().stop_level, &cu_u);
  flow.getV_32f_C1(flow.parameters().stop_level, &cu_v);
  flow.getIlluminationDifference_32f_C1(flow.parameters().stop_level, &cu_illumination);

  // copy gpu -> cpu
  iu::copy(&cu_u, &u);
  iu::copy(&cu_v, &v);
  iu::copy(&cu_illumination, &illumination);

  // display the opencv stuff - These are not normalized but I guess you get the idea....
  cv::imshow("u (x-disparities)", mat_u);
  cv::imshow("v (y-disparities)", mat_v);
  cv::imshow("illumination differences", mat_illumination);
#else
  // use imageutilties
    IuSize result_size;
    flow.getSize(flow.parameters().stop_level, result_size);

    iu::ImageGpu_32f_C1 u(result_size);
    iu::ImageGpu_32f_C1 v(result_size);
    iu::ImageGpu_32f_C1 c(result_size);
    iu::ImageGpu_8u_C4 cflow(result_size);

    flow.getU_32f_C1(flow.parameters().stop_level, &u);
    flow.getV_32f_C1(flow.parameters().stop_level, &v);
    flow.getIlluminationDifference_32f_C1(0, &c);
    flow.getColorFlow_8u_C4(flow.parameters().stop_level, &cflow, 0.0f);

    printf("display results ... \n");
    float min,max;
    iu::minMax(&u, u.roi(), min, max);
    iu::imshow(&u, "u - x-disparities", true);
    std::cout << "u = " << min << " .. " << max << ";    ";

    iu::minMax(&v, v.roi(), min, max);
    iu::imshow(&v, "v - y-disparities", true);
    std::cout << "v = " << min << " .. " << max << ";    ";

    iu::minMax(&c, c.roi(), min, max);
    iu::imshow(&c, "c - illumination estimation", true);
    std::cout << "c = " << min << " .. " << max << ";" << std::endl;

    iu::imshow(&cflow, "color coded flow field");
#endif
  cv::waitKey();
  return EXIT_SUCCESS;

  // Have fun! And do not hesitate to contact me if you have any problems. Or remarks. Or suggestions for the next release....
  // Best, Manuel.
}
